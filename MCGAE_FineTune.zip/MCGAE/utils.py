import scanpy as sc
import pandas as pd
import numpy as np
import scipy.sparse as sp
import stlearn as st
from pathlib import Path
import scipy
import os, ot, csv, re
import math, numba
import sklearn
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics.pairwise import cosine_similarity
from anndata import AnnData, read_csv, read_text, read_mtx
from scanpy import read_10x_h5
from scipy.sparse import issparse
from scipy.sparse.csc import csc_matrix
import random
import torch
from torch.backends import cudnn
import torch.nn as nn
from .layers import VAE

def load_dataset(dataset_path, use_image=True):
    adata = sc.read_visium(
        path=dataset_path, count_file="filtered_feature_bc_matrix.h5", load_images=True
    )
    adata.obs["x_pixel"] = adata.obsm["spatial"][:, 0].tolist()
    adata.obs["y_pixel"] = adata.obsm["spatial"][:, 1].tolist()
    adata.var_names_make_unique()
    if use_image:
        st.settings.set_figure_params(dpi=300)
        # spot tile is the intermediate result of image pre-processing
        TILE_PATH = Path(os.path.join(dataset_path,"image_segmentation"))
        TILE_PATH.mkdir(parents=True, exist_ok=True)
        # output path
        OUT_PATH = Path(os.path.join(dataset_path,"image_tile_result"))
        OUT_PATH.mkdir(parents=True, exist_ok=True)
        data = st.Read10X(dataset_path,
                          count_file="filtered_feature_bc_matrix.h5")
        st.pp.tiling(data,TILE_PATH)
        st.pp.extract_feature(data, n_components=100)
        adata.obs["tile_path"] = data.obs["tile_path"]
        adata.obsm["X_morphology"] = data.obsm["X_morphology"]

    return adata


def norm_and_filter(adata):
    sc.pp.filter_genes(adata, min_cells=1)
    sc.pp.filter_genes(adata, min_cells=1)
    sc.pp.highly_variable_genes(adata, flavor="seurat_v3", n_top_genes=3000)
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    # sc.pp.scale(adata, zero_center=False, max_value=10)
    adata = adata[:, adata.var["highly_variable"]]
    # if DLPFC , PCA OR NOT
    # VAE -->Z ----MCLUST
    return adata


def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.0
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx


def permutation(feature):
    # fix_seed(FLAGS.random_seed)
    ids = np.arange(feature.shape[0])
    ids = np.random.permutation(ids)
    feature_permutated = feature[ids]
    return feature_permutated


def construct_interaction(adata, n_neighbors=3):
    """
    Constructing spot-to-spot interactive graph
    this code is from GraphST
    """
    position = adata.obsm["spatial"]

    # calculate distance matrix
    distance_matrix = ot.dist(position, position, metric="euclidean")
    n_spot = distance_matrix.shape[0]

    adata.obsm["distance_matrix"] = distance_matrix

    # find k-nearest neighbors
    interaction = np.zeros([n_spot, n_spot])
    for i in range(n_spot):
        vec = distance_matrix[i, :]
        distance = vec.argsort()
        for t in range(1, n_neighbors + 1):
            y = distance[t]
            interaction[i, y] = 1

    adata.obsm["graph_neigh"] = interaction

    # transform adj to symmetrical adj
    adj = interaction
    adj = adj + adj.T
    adj = np.where(adj > 1, 1, adj)

    adata.obsm["adj"] = adj


def construct_interaction_KNN(adata, n_neighbors=3):
    position = adata.obsm["spatial"]
    n_spot = position.shape[0]
    nbrs = NearestNeighbors(n_neighbors=n_neighbors + 1).fit(position)
    _, indices = nbrs.kneighbors(position)
    x = indices[:, 0].repeat(n_neighbors)
    y = indices[:, 1:].flatten()
    interaction = np.zeros([n_spot, n_spot])
    interaction[x, y] = 1

    adata.obsm["graph_orig"] = interaction

    # transform adj to symmetrical adj
    adj = interaction
    adj = adj + adj.T
    adj = np.where(adj > 1, 1, adj)

    adata.obsm["adj_orig"] = adj
    print("Graph constructed!")


def construct_interaction_cosine(adata, n_neighbors=3):
    """Constructing spot-to-spot interactive graph"""
    position = adata.obsm["spatial"]

    # calculate cosine similarity matrix
    similarity_matrix = cosine_similarity(position)
    n_spot = similarity_matrix.shape[0]

    adata.obsm["similarity_matrix"] = similarity_matrix

    # find k-nearest neighbors
    interaction = np.zeros([n_spot, n_spot])
    for i in range(n_spot):
        vec = similarity_matrix[i, :]
        neighbors = vec.argsort()[::-1][1 : n_neighbors + 1]
        interaction[i, neighbors] = 1

    adata.obsm["graph_neigh_hat"] = interaction
    # transform adj to symmetrical adj
    adj = interaction
    adj = adj + adj.T
    adj = np.where(adj > 1, 1, adj)
    adata.obsm["adj_aug"] = adj
    print("Graph_hat constructed!")


def get_feature(adata, n_components=50):
    pca = PCA(n_components=n_components)
    if issparse(adata.X):
        pca.fit(adata.X.A)
        embed = pca.transform(adata.X.A)
        raw_exp = adata.X.A
    else:
        raw_exp = adata.X
        pca.fit(adata.X)
        embed = pca.transform(adata.X)
    feat_pca = embed
    feat_orig = raw_exp
    feat_corr = permutation(feat_orig)
    feat_pca_corr = permutation(feat_pca)
    adata.obsm["feat_orig"] = feat_orig
    adata.obsm["feat_pca_orig"] = feat_pca
    adata.obsm["feat_corr"] = feat_corr
    adata.obsm["feat_pca_corr"] = feat_pca_corr


def get_feature_vae(adata, n_epochs=200, batch_size=128, n_components=50):
    n_input = adata.X.shape[1]
    n_hidden = 256
    n_latent = 20
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    vae = VAE(n_input, n_hidden, n_latent).to(device)
    x = torch.Tensor(adata.X.A).to(device)
    optimizer = torch.optim.Adam(vae.parameters(), lr=0.001)
    vae.train_vae(optimizer, x, n_epochs, batch_size)
    feat_vae, _, _ = vae.forward(x)
    feat_vae = feat_vae.detach().cpu().numpy()

    pca = PCA(n_components=n_components)
    if issparse(feat_vae):
        pca.fit(feat_vae)
        embed = pca.transform(feat_vae)
        feat_feat_vae = feat_vae.A
    else:
        pca.fit(feat_vae)
        embed = pca.transform(feat_vae)
    adata.obsm["feat_pca_vae"] = embed
    adata.obsm["feat_vae"] = feat_vae


def add_contrastive_label(adata):
    # contrastive label
    n_spot = adata.n_obs
    one_matrix = np.ones([n_spot, 1])
    zero_matrix = np.zeros([n_spot, 1])
    label_cls = np.concatenate([one_matrix, zero_matrix], axis=1)
    adata.obsm["label_cls"] = label_cls


def normalize_adj(adj):
    """Symmetrically normalize adjacency matrix."""
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    adj = adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt)
    return adj.toarray()


def preprocess_adj(adj):
    """Preprocessing of adjacency matrix for simple GCN model and conversion to tuple representation."""
    adj_normalized = normalize_adj(adj) + np.eye(adj.shape[0])
    return adj_normalized


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64)
    )
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


def preprocess_adj_sparse(adj):
    adj = sp.coo_matrix(adj)
    adj_ = adj + sp.eye(adj.shape[0])
    rowsum = np.array(adj_.sum(1))
    degree_mat_inv_sqrt = sp.diags(np.power(rowsum, -0.5).flatten())
    adj_normalized = (
        adj_.dot(degree_mat_inv_sqrt).transpose().dot(degree_mat_inv_sqrt).tocoo()
    )
    return sparse_mx_to_torch_sparse_tensor(adj_normalized)


def set_seed(seed):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cudnn.deterministic = True
    cudnn.benchmark = False

    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"


@numba.njit("f4(f4[:], f4[:])", nopython=True)
def euclid_dist(t1, t2):
    sum = 0
    for i in range(t1.shape[0]):
        sum += (t1[i] - t2[i]) ** 2
    return np.sqrt(sum)


@numba.njit("f4[:,:](f4[:,:])", parallel=True, nogil=True, nopython=True)
def pairwise_distance(X):
    n = X.shape[0]
    adj = np.empty((n, n), dtype=np.float32)
    for i in numba.prange(n):
        for j in numba.prange(n):
            adj[i][j] = euclid_dist(X[i], X[j])
    return adj


def extract_color(x_pixel=None, y_pixel=None, image=None, beta=49):
    # beta to control the range of neighbourhood when calculate grey vale for one spot
    beta_half = round(beta / 2)
    g = []
    for i in range(len(x_pixel)):
        max_x = image.shape[0]
        max_y = image.shape[1]
        nbs = image[
            max(0, x_pixel[i] - beta_half) : min(max_x, x_pixel[i] + beta_half + 1),
            max(0, y_pixel[i] - beta_half) : min(max_y, y_pixel[i] + beta_half + 1),
        ]
        g.append(np.mean(np.mean(nbs, axis=0), axis=0))
    c0, c1, c2 = [], [], []
    for i in g:
        c0.append(i[0])
        c1.append(i[1])
        c2.append(i[2])
    c0 = np.array(c0)
    c1 = np.array(c1)
    c2 = np.array(c2)
    c3 = (c0 * np.var(c0) + c1 * np.var(c1) + c2 * np.var(c2)) / (
        np.var(c0) + np.var(c1) + np.var(c2)
    )
    return c3


def calculate_adj_matrix(
    x, y, x_pixel=None, y_pixel=None, image=None, beta=49, alpha=1, histology=False
):
    # x,y,x_pixel, y_pixel are lists
    X = np.array([x, y]).T.astype(np.float32)
    adj = pairwise_distance(X)
    return adj


def mclust_R(
    adata, num_cluster, modelNames="EEE", used_obsm="emb_pca", random_seed=2020
):
    """\
    Clustering using the mclust algorithm.
    The parameters are the same as those in the R package mclust.
    can not use in windows
    """

    np.random.seed(random_seed)
    import rpy2.robjects as robjects
    robjects.r.library("mclust")

    import rpy2.robjects.numpy2ri
    rpy2.robjects.numpy2ri.activate()
    r_random_seed = robjects.r['set.seed']
    r_random_seed(random_seed)
    rmclust = robjects.r['Mclust']

    res = rmclust(rpy2.robjects.numpy2ri.numpy2rpy(adata.obsm[used_obsm]), num_cluster, modelNames)
    mclust_res = np.array(res[-2])

    adata.obs['mclust'] = mclust_res
    adata.obs['mclust'] = adata.obs['mclust'].astype('int')
    adata.obs['mclust'] = adata.obs['mclust'].astype('category')
    return adata
    
    
def refine_label(adata, radius=50, key='label'):
    n_neigh = radius
    new_type = []
    old_type = adata.obs[key].values
    
    #calculate distance
    position = adata.obsm['spatial']
    distance = ot.dist(position, position, metric='euclidean')
           
    n_cell = distance.shape[0]
    
    for i in range(n_cell):
        vec  = distance[i, :]
        index = vec.argsort()
        neigh_type = []
        for j in range(1, n_neigh+1):
            neigh_type.append(old_type[index[j]])
        max_type = max(neigh_type, key=neigh_type.count)
        new_type.append(max_type)
        
    new_type = [str(i) for i in list(new_type)]    
    #adata.obs['label_refined'] = np.array(new_type)
    
    return new_type   


def search_res(adata, n_clusters, method="leiden", start=0.1, end=2.0, increment=0.05, rep=None):
    """
    Searching corresponding resolution according to given cluster number

    """
    print("Searching resolution...")
    label = 0
    sc.pp.neighbors(adata, n_neighbors=10, use_rep=rep)
    res = 0.4
    count_unique = None
    for res in sorted(list(np.arange(start, end, increment)), reverse=True):
        if method == "leiden":
            sc.tl.leiden(adata, random_state=0, resolution=res)
            count_unique = len(pd.DataFrame(adata.obs["leiden"]).leiden.unique())
            print('resolution={}, cluster number={}'.format(res, count_unique))
        elif method == "louvain":
            sc.tl.louvain(adata, random_state=0, resolution=res)
            count_unique = len(pd.DataFrame(adata.obs["louvain"]).louvain.unique())
            # print('resolution={}, cluster number={}'.format(res, count_unique))
        if count_unique == n_clusters:
            label = 1
            break

    if label != 1:
        res = 1.8
        print("********************************************manual set")

    return res


def compute_adata_components(adata, n_components=50):
    if 'adj_orig' not in adata.obsm.keys():
        construct_interaction_KNN(adata)

    if 'label_cls' not in adata.obsm.keys():
        add_contrastive_label(adata)

    if 'feat' not in adata.obsm.keys():
        get_feature(adata, n_components=n_components)

    if 'feat_vae' not in adata.obsm.keys():
        get_feature_vae(adata, n_epochs=100, batch_size=256, n_components=n_components)

    if "adj_aug" not in adata.obsm.keys():
        construct_interaction_cosine(adata)
